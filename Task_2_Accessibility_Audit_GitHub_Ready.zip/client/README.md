# Client

Frontend boundary for UI, semantic HTML, responsive design, accessibility, and API consumption.

Planned responsibilities:
- Semantic page structure
- Keyboard navigation
- Responsive layout
- Accessible forms and controls
- API client integration

# Server

Backend boundary for API routes, validation, business logic, and data access.

Planned responsibilities:
- REST API endpoints
- Request validation
- Business rules
- Data persistence boundary
- Error handling

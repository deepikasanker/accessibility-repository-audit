# Accessibility Baseline & Repository Architecture Audit

## Project
This repository contains the deliverables for Task 2 of the Full Stack Web Development Internship.

## Objective
- Audit a public-facing website for accessibility.
- Record evidence and remediation priorities.
- Define a maintainable full-stack repository structure.
- Document local setup and architecture boundaries.

## Repository Structure

```text
.
├── client/
│   └── README.md
├── server/
│   └── README.md
├── docs/
│   ├── accessibility-audit.md
│   └── architecture.md
└── tests/
    └── README.md
```

## Architecture Boundaries

### Client
Responsible for UI rendering, semantic HTML, responsive behaviour, accessibility, and API consumption.

### Server
Responsible for API endpoints, validation, business logic, and data access. The server must not contain presentation-layer code.

### Docs
Contains accessibility findings, evidence, architecture decisions, and setup documentation.

### Tests
Contains automated and manual test plans for accessibility and application behaviour.

## Local Setup

This Task 2 repository is documentation-first. No external package installation is required.

```bash
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd <YOUR_REPOSITORY_NAME>
```

Open `docs/accessibility-audit.md` and complete the Lighthouse values and screenshots after running the audit locally.

## First Vertical Feature Slice

The first planned feature slice is an accessible public information page:
1. Semantic page structure.
2. Keyboard-accessible navigation.
3. Responsive layout.
4. Accessible form controls.
5. API-ready data boundary.

## Evidence
See `docs/accessibility-audit.md` and `docs/architecture.md`.

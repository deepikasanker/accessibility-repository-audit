# Task 3 - Semantic HTML5 & Accessible Component Architecture

## Objective
Build an accessible multi-page enterprise dashboard using semantic HTML5, WCAG-oriented form controls, and a clear document hierarchy.

## Included
- Semantic `header`, `nav`, `main`, `section`, `article`, `aside`, and `footer`.
- Skip link for keyboard users.
- Visible keyboard focus styles.
- Accessible tables with captions and scoped headers.
- Forms with labels, fieldsets, legends, validation, and descriptive text.
- Native HTML dialog component.
- Multi-page navigation.
- Responsive CSS.

## Pages
- `index.html` - dashboard, records table, contact form, and dialog.
- `pages/users.html` - user directory.
- `pages/settings.html` - settings form.

## Validation
Open the HTML files in the W3C Nu HTML Checker / Markup Validation Service and confirm there are no syntax errors before submission.

## GitHub submission
Upload this repository to GitHub and submit the public repository URL as the proof link.

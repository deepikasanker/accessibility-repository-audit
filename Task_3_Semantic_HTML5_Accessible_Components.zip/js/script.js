const dialog = document.getElementById("project-dialog");
const openButton = document.getElementById("open-dialog");
const closeButton = document.getElementById("close-dialog");

if (dialog && openButton && closeButton) {
  openButton.addEventListener("click", () => dialog.showModal());
  closeButton.addEventListener("click", () => dialog.close());
}
